from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
import time

def count_primes(limit):
    count = 0
    for n in range(2, limit + 1):
        is_prime = True
        d = 2
        while d * d <= n:
            if n % d == 0:
                is_prime = False
                break
            d += 1
        if is_prime:
            count += 1
    return count

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        params = parse_qs(urlparse(self.path).query)
        limit = int(params.get("n", ["20000"])[0])
        limit = max(2, min(limit, 1000000))

        start = time.time()
        primes = count_primes(limit)
        elapsed = time.time() - start

        body = json.dumps({
            "server": "server2",
            "limit": limit,
            "prime_count": primes,
            "compute_seconds": round(elapsed, 4)
        }).encode()

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.client_address[0], fmt % args))

server = ThreadingHTTPServer(("0.0.0.0", 8000), Handler)
print("CPU server listening on port 8000", flush=True)
server.serve_forever()
