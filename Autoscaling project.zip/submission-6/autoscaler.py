import csv
import json
import os
import time
import urllib.request

import libvirt

libvirt.registerErrorHandler(lambda ctx, err: None, None)

VM1_NAME = "server1"
VM2_NAME = "server2"

# ---- scale-out: add server2 -------------------------------------------
THRESHOLD = 60.0            # server1 CPU % at or above this counts as "high"
CHECK_INTERVAL = 2          # seconds between CPU samples
REQUIRED_HIGH_SAMPLES = 2   # consecutive high samples before scaling out
BOOT_TIMEOUT = 180          # seconds to wait for server2's application

# ---- scale-in: remove server2 ------------------------------------------
# Hysteresis: scale-in needs BOTH servers below 25 %, so one server alone
# would carry less than 50 %, well under the 60 % scale-out threshold.
SCALE_IN_THRESHOLD = 25.0   # both servers below this CPU % counts as "low"
REQUIRED_LOW_SAMPLES = 5    # consecutive low samples (5 x 2 s = 10 s)
MIN_TWO_SERVER_TIME = 20    # seconds after server2 is published before scale-in is considered
DRAIN_SECONDS = 5           # let in-flight requests finish after server2 leaves the list
SHUTDOWN_TIMEOUT = 60       # force server2 off if a graceful shutdown takes longer
UNDEFINE_ON_SCALE_IN = True # also remove server2's definition (disk is kept);
                            # the next scale-out defines it again from server2.xml

BASE = os.path.dirname(os.path.abspath(__file__))
SERVERS_FILE = os.path.join(BASE, "available_servers.json")
CPU_LOG = os.path.join(BASE, "cpu_log.csv")
EVENT_LOG = os.path.join(BASE, "events.csv")
SERVER2_XML = os.path.join(BASE, "server2.xml")

SERVER1_URL = "http://192.168.122.202:8000"
SERVER2_URL = "http://192.168.122.21:8000"


def publish_servers(servers):
    tmp = SERVERS_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(servers, f)
    os.replace(tmp, SERVERS_FILE)
    print("Published server list:", servers, flush=True)


def server_ready(url):
    try:
        with urllib.request.urlopen(url + "/?n=100", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def init_logs():
    with open(CPU_LOG, "w", newline="") as f:
        csv.writer(f).writerow(["timestamp", "vm", "cpu_percent"])
    with open(EVENT_LOG, "w", newline="") as f:
        csv.writer(f).writerow(["timestamp", "event"])


def log_cpu(vm, cpu):
    with open(CPU_LOG, "a", newline="") as f:
        csv.writer(f).writerow([f"{time.time():.3f}", vm, f"{cpu:.2f}"])


def log_event(event):
    print(f"EVENT: {event}", flush=True)
    with open(EVENT_LOG, "a", newline="") as f:
        csv.writer(f).writerow([f"{time.time():.3f}", event])


prev = {}


def find_domain(conn, name):
    """Return the libvirt domain, or None if it is not defined."""
    try:
        return conn.lookupByName(name)
    except libvirt.libvirtError:
        return None


def sample(conn, name):
    """CPU % of a running domain since the last sample (None if not running)."""
    dom = find_domain(conn, name)
    if dom is None:
        prev.pop(name, None)      # domain not defined (yet / any more)
        return None
    info = dom.info()
    now = time.monotonic()
    if info[0] != libvirt.VIR_DOMAIN_RUNNING:
        prev.pop(name, None)
        return None
    cpu_ns = info[4]
    util = None
    if name in prev:
        p_cpu, p_t = prev[name]
        util = 100.0 * ((cpu_ns - p_cpu) / 1e9) / (now - p_t)
        util = max(0.0, min(100.0, util))
    prev[name] = (cpu_ns, now)
    return util


def get_or_define_vm2(conn):
    """Return the server2 domain; define it from server2.xml if it is missing."""
    dom = find_domain(conn, VM2_NAME)
    if dom is not None:
        return dom
    with open(SERVER2_XML) as f:
        xml = f.read()
    dom = conn.defineXML(xml)
    if dom is None:
        raise RuntimeError("defineXML failed for server2")
    log_event("VM2_DEFINED_FROM_XML")
    return dom


def undefine_vm2(conn):
    """Remove server2's definition. The disk image is NOT deleted."""
    dom = find_domain(conn, VM2_NAME)
    if dom is None:
        return
    try:
        dom.undefine()
        log_event("SERVER2_UNDEFINED")
    except libvirt.libvirtError as exc:
        log_event("SERVER2_UNDEFINE_FAILED")
        print("undefine failed:", exc, flush=True)


def main():
    conn = libvirt.open("qemu:///system")
    if conn is None:
        raise SystemExit("Cannot connect to libvirt")

    vm1 = find_domain(conn, VM1_NAME)
    if vm1 is None or not vm1.isActive():
        raise SystemExit("server1 must be running before autoscaling")
    if not os.path.exists(SERVER2_XML):
        raise SystemExit(f"{SERVER2_XML} not found (needed to create server2)")

    init_logs()
    publish_servers([SERVER1_URL])
    log_event("AUTOSCALER_START")

    # States: ONE_SERVER -> SCALING_OUT -> TWO_SERVERS -> DRAINING -> STOPPING -> ONE_SERVER
    state = "ONE_SERVER"
    high_samples = 0
    low_samples = 0
    t_mark = 0.0               # time the current state was entered

    # Start from a clean N=1 situation: stop / remove a leftover server2.
    vm2 = find_domain(conn, VM2_NAME)
    if vm2 is not None:
        if vm2.isActive():
            log_event("STARTUP_SERVER2_FOUND_RUNNING")
            vm2.shutdown()
            state = "STOPPING"
            t_mark = time.monotonic()
        elif UNDEFINE_ON_SCALE_IN:
            undefine_vm2(conn)

    sample(conn, VM1_NAME)
    sample(conn, VM2_NAME)

    try:
        while True:
            time.sleep(CHECK_INTERVAL)

            cpu1 = sample(conn, VM1_NAME)
            cpu2 = sample(conn, VM2_NAME)
            if cpu1 is not None:
                log_cpu(VM1_NAME, cpu1)
                print(f"server1 CPU: {cpu1:.1f}%", flush=True)
            if cpu2 is not None:
                log_cpu(VM2_NAME, cpu2)
                print(f"server2 CPU: {cpu2:.1f}%", flush=True)

            now = time.monotonic()

            if state == "ONE_SERVER":
                if cpu1 is not None and cpu1 >= THRESHOLD:
                    high_samples += 1
                else:
                    high_samples = 0

                if high_samples >= REQUIRED_HIGH_SAMPLES:
                    log_event("OVERLOAD_DETECTED")
                    vm2 = get_or_define_vm2(conn)
                    if not vm2.isActive():
                        vm2.create()
                    log_event("VM2_CREATE_CALLED")
                    t_mark = now
                    state = "SCALING_OUT"

            elif state == "SCALING_OUT":
                if server_ready(SERVER2_URL):
                    publish_servers([SERVER1_URL, SERVER2_URL])
                    log_event("SERVER2_READY_PUBLISHED")
                    t_mark = now
                    low_samples = 0
                    state = "TWO_SERVERS"
                elif now - t_mark > BOOT_TIMEOUT:
                    log_event("SCALE_TIMEOUT")
                    high_samples = 0
                    state = "ONE_SERVER"

            elif state == "TWO_SERVERS":
                both_low = (cpu1 is not None and cpu2 is not None
                            and cpu1 < SCALE_IN_THRESHOLD
                            and cpu2 < SCALE_IN_THRESHOLD)
                if now - t_mark >= MIN_TWO_SERVER_TIME and both_low:
                    low_samples += 1
                else:
                    low_samples = 0

                if low_samples >= REQUIRED_LOW_SAMPLES:
                    log_event("LOW_LOAD_DETECTED")
                    publish_servers([SERVER1_URL])      # client stops using server2
                    log_event("SERVER2_REMOVED_FROM_LIST")
                    t_mark = now
                    state = "DRAINING"

            elif state == "DRAINING":
                if now - t_mark >= DRAIN_SECONDS:
                    vm2 = find_domain(conn, VM2_NAME)
                    if vm2 is not None and vm2.isActive():
                        vm2.shutdown()                  # graceful (ACPI) shutdown
                        log_event("SERVER2_SHUTDOWN_CALLED")
                    t_mark = now
                    state = "STOPPING"

            elif state == "STOPPING":
                vm2 = find_domain(conn, VM2_NAME)
                stopped = vm2 is None or not vm2.isActive()
                if not stopped and now - t_mark > SHUTDOWN_TIMEOUT:
                    vm2.destroy()                       # force off
                    log_event("SERVER2_FORCED_OFF")
                    stopped = True
                if stopped:
                    log_event("SERVER2_STOPPED")
                    if UNDEFINE_ON_SCALE_IN:
                        undefine_vm2(conn)
                    high_samples = 0
                    state = "ONE_SERVER"

    except KeyboardInterrupt:
        print("\nAutoscaler stopped.", flush=True)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
