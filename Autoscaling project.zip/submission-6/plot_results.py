import csv
import os
import re
import statistics

import matplotlib
matplotlib.use("Agg")          # no display needed; we only save PNG files
import matplotlib.pyplot as plt
import numpy as np

BASE = os.environ.get("PROJECT_DIR", os.path.dirname(os.path.abspath(__file__)))
BIN = 5            # seconds per bin for latency / throughput curves
SETTLE_OUT = 15    # s after server2 is published before the "after scale-out" window starts
SETTLE_IN = 5      # fallback: s after server2 leaves the list if no SERVER2_STOPPED event is found
GAP = 6            # break plotted CPU lines where samples are further apart than this (s)


def read_csv(name):
    path = os.path.join(BASE, name)
    if not os.path.exists(path):
        raise SystemExit(f"Missing {path}")
    with open(path) as f:
        return list(csv.DictReader(f))


cpu_rows = read_csv("cpu_log.csv")
event_rows = read_csv("events.csv")
req_rows = read_csv("integrated_demo_results.csv")

# events: first word of the event text -> sorted list of (time, full text)
events = {}
for e in event_rows:
    text = e["event"]
    events.setdefault(text.split()[0], []).append((float(e["timestamp"]), text))
for v in events.values():
    v.sort()

if "AUTOSCALER_START" not in events:
    raise SystemExit("events.csv has no AUTOSCALER_START; run the demo first")

T0 = events["AUTOSCALER_START"][0][0]
rel = lambda t: t - T0


def times(key):
    return [rel(t) for t, _ in events.get(key, [])]


# ---------- load data ----------
cpu = {}
for r in cpu_rows:
    cpu.setdefault(r["vm"], ([], []))
    cpu[r["vm"]][0].append(rel(float(r["timestamp"])))
    cpu[r["vm"]][1].append(float(r["cpu_percent"]))

reqs = []
for r in req_rows:
    reqs.append({
        "start": rel(float(r["start_time"])),
        "end": rel(float(r["end_time"])),
        "lat": float(r["latency_seconds"]),
        "ok": r["success"] == "True",
        "server": r["reported_server"] or r["server"],
    })
good = [r for r in reqs if r["ok"]]
if not good:
    raise SystemExit("No successful requests in the results CSV")

tmax = max(r["end"] for r in good)

# ---------- load phases (from the client's events) ----------
phase_events = sorted((t, k, text) for k in ("CLIENT_LOW_START", "CLIENT_HIGH_START")
                      for t, text in events.get(k, []))
if not phase_events:
    raise SystemExit("events.csv has no CLIENT_*_START events; run the client first")
send_done = (rel(events["CLIENT_SENDING_DONE"][0][0])
             if "CLIENT_SENDING_DONE" in events else tmax)
phases = []
for i, (t, k, text) in enumerate(phase_events):
    kind = "LOW" if "LOW" in k else "HIGH"
    m = re.search(r"phase=(\S+)", text)
    phases.append({
        "name": m.group(1) if m else kind,
        "kind": kind,
        "start": rel(t),
        "end": rel(phase_events[i + 1][0]) if i + 1 < len(phase_events) else send_done,
    })

# ---------- binned curves ----------
edges = np.arange(0, tmax + BIN, BIN)
centers = edges[:-1] + BIN / 2
mean_lat, p95_lat = [], []
for lo, hi in zip(edges[:-1], edges[1:]):
    lats = [r["lat"] for r in good if lo <= r["start"] < hi]
    mean_lat.append(statistics.mean(lats) if lats else np.nan)
    p95_lat.append(np.percentile(lats, 95) if lats else np.nan)

servers = sorted({r["server"] for r in good})
tput = {}
for s in servers:
    counts, _ = np.histogram([r["end"] for r in good if r["server"] == s], bins=edges)
    tput[s] = counts / BIN
total_tput = sum(tput.values())

# ---------- markers ----------
markers = [
    ("VM2_CREATE_CALLED", "server2 create()", "orange", "--"),
    ("SERVER2_READY_PUBLISHED", "server2 ready, added to client list", "red", "-"),
    ("SERVER2_REMOVED_FROM_LIST", "server2 removed from client list", "purple", "-"),
    ("SERVER2_STOPPED", "server2 stopped", "green", "--"),
]


def add_markers(ax, label=False):
    first = True
    for p in phases:
        ax.axvline(p["start"], color="gray", linestyle=":", linewidth=1.2,
                   label="load phase change" if (label and first) else None)
        first = False
    for key, text, color, style in markers:
        for i, x in enumerate(times(key)):
            ax.axvline(x, color=color, linestyle=style, linewidth=1.5,
                       label=text if (label and i == 0) else None)


def with_gaps(t, c):
    """Insert NaN where CPU samples are far apart so the line is not drawn across a gap."""
    tt, cc = [], []
    for i, (x, y) in enumerate(zip(t, c)):
        if i and x - t[i - 1] > GAP:
            tt.append((t[i - 1] + x) / 2)
            cc.append(np.nan)
        tt.append(x)
        cc.append(y)
    return tt, cc


# ---------- combined figure ----------
fig, axes = plt.subplots(3, 1, figsize=(12, 10.5), sharex=True)

ax = axes[0]
for vm, (t, c) in sorted(cpu.items()):
    tt, cc = with_gaps(t, c)
    ax.plot(tt, cc, marker=".", label=f"{vm} CPU")
ax.axhline(60, color="black", linestyle="-.", linewidth=0.8, label="scale-out threshold (60%)")
ax.axhline(25, color="gray", linestyle="-.", linewidth=0.8, label="scale-in threshold (25%)")
add_markers(ax, label=True)
for p in phases:
    ax.text(p["start"] + 1, 103, p["name"], fontsize=8, color="dimgray")
ax.set_ylabel("CPU utilization (%)")
ax.set_ylim(0, 110)
ax.set_title("Autoscaling demo: CPU, latency and throughput", pad=52)
ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), fontsize=7.5, ncol=4, frameon=False)

ax = axes[1]
ax.plot(centers, mean_lat, marker="o", label="mean latency")
ax.plot(centers, p95_lat, marker="s", label="P95 latency")
add_markers(ax)
ax.set_ylabel("Latency (s)")
ax.legend(loc="upper right", fontsize=8)

ax = axes[2]
for s in servers:
    ax.plot(centers, tput[s], marker=".", label=f"{s} completed/s")
ax.plot(centers, total_tput, color="black", linewidth=2, label="total")
add_markers(ax)
ax.set_ylabel("Throughput (req/s)")
ax.set_xlabel(f"Time since autoscaler start (s)   [{BIN}s bins]")
ax.legend(loc="upper right", fontsize=8)

fig.tight_layout()
fig.savefig(os.path.join(BASE, "autoscaling_summary.png"), dpi=150)
print("Saved autoscaling_summary.png")

# ---------- autoscaler event timeline ----------
print("\nEvents (seconds since autoscaler start):")
for t, text in sorted((t, text) for v in events.values() for t, text in v):
    print(f"  {rel(t):7.1f}s  {text}")

# ---------- window table ----------
windows = []
for p in phases:
    s, e, n = p["start"], p["end"], p["name"]
    if p["kind"] == "HIGH":
        ready = [x for x in times("SERVER2_READY_PUBLISHED") if s <= x < e]
        if ready:
            windows.append((f"{n}: before scale-out", s, ready[0]))
            windows.append((f"{n}: after scale-out (+{SETTLE_OUT}s)", ready[0] + SETTLE_OUT, e))
        else:
            windows.append((f"{n}: no scale-out", s, e))
    else:
        removed = [x for x in times("SERVER2_REMOVED_FROM_LIST") if s <= x < e]
        if removed:
            stopped = [x for x in times("SERVER2_STOPPED") if removed[0] <= x < e]
            after_start = stopped[0] if stopped else removed[0] + SETTLE_IN
            windows.append((f"{n}: two servers, before scale-in", s, removed[0]))
            windows.append((f"{n}: one server, after scale-in", after_start, e))
        else:
            windows.append((n, s, e))

rows = []
for name, lo, hi in windows:
    if hi - lo < 3:
        continue
    span = hi - lo
    sel = [r for r in good if lo <= r["start"] < hi]
    failed = sum(1 for r in reqs if (not r["ok"]) and lo <= r["start"] < hi)
    done = sum(1 for r in good if lo <= r["end"] < hi)
    lats = [r["lat"] for r in sel]

    def cpu_mean(vm):
        if vm not in cpu:
            return float("nan")
        v = [c for t, c in zip(*cpu[vm]) if lo <= t < hi]
        return statistics.mean(v) if v else float("nan")

    rows.append({
        "window": name,
        "seconds": round(span, 1),
        "server1_cpu_%": round(cpu_mean("server1"), 1),
        "server2_cpu_%": round(cpu_mean("server2"), 1),
        "mean_latency_s": round(statistics.mean(lats), 3) if lats else "",
        "p95_latency_s": round(float(np.percentile(lats, 95)), 3) if lats else "",
        "throughput_req_s": round(done / span, 2),
        "failed_requests": failed,
    })

if rows:
    keys = list(rows[0].keys())
    print()
    print(" | ".join(keys))
    for r in rows:
        print(" | ".join(str(r[k]) for k in keys))
    with open(os.path.join(BASE, "summary_stats.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print("\nSaved summary_stats.csv")
