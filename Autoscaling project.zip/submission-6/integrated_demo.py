import concurrent.futures
import csv
import json
import os
import statistics
import threading
import time

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
SERVERS_FILE = os.path.join(BASE, "available_servers.json")
EVENT_LOG = os.path.join(BASE, "events.csv")
RESULTS_FILE = os.path.join(BASE, "integrated_demo_results.csv")

SERVER1 = "http://192.168.122.202:8000"

N = 20000              # same request size in every phase
LOW_RATE = 25          # requests per second
HIGH_RATE = 70
REQUEST_TIMEOUT = 60
MAX_WORKERS = 1000

# (phase name, requests per second, duration in seconds)
PHASES = [
    ("LOW-1",  LOW_RATE,  20),   # one server, no scaling
    ("HIGH-1", HIGH_RATE, 60),   # overload -> scale out to two servers
    ("LOW-2",  LOW_RATE,  70),   # load drops -> scale in back to one server
    ("HIGH-2", HIGH_RATE, 60),   # overload again -> server2 is created again
]

results = []
results_lock = threading.Lock()
counter = 0
counter_lock = threading.Lock()


def get_servers():
    try:
        with open(SERVERS_FILE) as f:
            servers = json.load(f)
        return servers if servers else [SERVER1]
    except (FileNotFoundError, json.JSONDecodeError):
        return [SERVER1]


def choose_server():
    global counter
    with counter_lock:
        servers = get_servers()
        server = servers[counter % len(servers)]
        counter += 1
        return server


def log_event(event):
    print(f"EVENT: {event}", flush=True)
    with open(EVENT_LOG, "a", newline="") as f:
        csv.writer(f).writerow([f"{time.time():.3f}", event])


def send_request(phase):
    server = choose_server()
    start_wall = time.time()
    start = time.perf_counter()
    ok, error, payload = False, "", {}
    try:
        r = requests.get(f"{server}/?n={N}", timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        payload = r.json()
        ok = True
    except Exception as exc:
        error = str(exc)
    latency = time.perf_counter() - start
    with results_lock:
        results.append({
            "start_time": round(start_wall, 3),
            "end_time": round(time.time(), 3),
            "phase": phase,
            "server": server,
            "limit": N,
            "latency_seconds": round(latency, 4),
            "success": ok,
            "reported_server": payload.get("server", ""),
            "error": error,
        })


def run_phase(phase, rate, duration, pool):
    """Open loop: send `rate` requests/sec regardless of reply speed."""
    interval = 1.0 / rate
    t0 = time.perf_counter()
    next_t = t0
    end = t0 + duration
    while next_t < end:
        delay = next_t - time.perf_counter()
        if delay > 0:
            time.sleep(delay)
        pool.submit(send_request, phase)
        next_t += interval


def report(phase, duration):
    rows = [r for r in results if r["phase"] == phase]
    good = [r for r in rows if r["success"]]
    print(f"\n--- {phase} ---")
    print(f"Successful requests: {len(good)}/{len(rows)}")
    if not good:
        return
    lat = sorted(r["latency_seconds"] for r in good)
    p95 = lat[min(len(lat) - 1, int(0.95 * (len(lat) - 1)))]
    print(f"Throughput (completed/duration): {len(good) / duration:.2f} req/s")
    print(f"Mean latency: {statistics.mean(lat):.3f} s")
    print(f"Median latency: {statistics.median(lat):.3f} s")
    print(f"P95 latency: {p95:.3f} s")
    counts = {}
    for r in good:
        k = r["reported_server"] or r["server"]
        counts[k] = counts.get(k, 0) + 1
    print("Requests by server:", counts)


def main():
    total = sum(d for _, _, d in PHASES)
    print("Initial published servers:", get_servers())
    print("Schedule:", " -> ".join(f"{n} ({r} req/s, {d} s)" for n, r, d in PHASES),
          f"[total {total} s]")
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        for name, rate, duration in PHASES:
            kind = name.split("-")[0]          # LOW or HIGH
            log_event(f"CLIENT_{kind}_START phase={name} rate={rate}")
            run_phase(name, rate, duration, pool)
        log_event("CLIENT_SENDING_DONE")
    # leaving the 'with' block waits for in-flight requests to finish
    log_event("CLIENT_ALL_DONE")

    for name, _, duration in PHASES:
        report(name, duration)
    print("\nFinal published servers:", get_servers())

    with open(RESULTS_FILE, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "start_time", "end_time", "phase", "server", "limit",
            "latency_seconds", "success", "reported_server", "error"])
        w.writeheader()
        w.writerows(results)
    print("Saved", RESULTS_FILE)


if __name__ == "__main__":
    main()
