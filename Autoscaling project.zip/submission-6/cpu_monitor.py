import libvirt
import time

VM_NAME = "server1"
INTERVAL = 2

conn = libvirt.open("qemu:///system")
if conn is None:
    raise SystemExit("Could not connect to libvirt")

vm = conn.lookupByName(VM_NAME)
previous_cpu_time = vm.info()[4]
previous_time = time.monotonic()

print(f"Monitoring CPU usage for {VM_NAME}. Press Ctrl+C to stop.")

try:
    while True:
        time.sleep(INTERVAL)

        vm = conn.lookupByName(VM_NAME)
        current_cpu_time = vm.info()[4]
        current_time = time.monotonic()

        elapsed = current_time - previous_time
        cpu_elapsed = (current_cpu_time - previous_cpu_time) / 1e9

        if elapsed > 0:
            utilization = 100 * cpu_elapsed / elapsed
            utilization = max(0, min(100, utilization))
            print(f"CPU utilization: {utilization:5.1f}%")

        previous_cpu_time = current_cpu_time
        previous_time = current_time

except KeyboardInterrupt:
    print("\nMonitoring stopped.")
finally:
    conn.close()
