import csv
import os
import statistics

import matplotlib
matplotlib.use("Agg")          # no display needed; we only save PNG files
import matplotlib.pyplot as plt
import numpy as np

BASE = os.environ.get("PROJECT_DIR", os.path.dirname(os.path.abspath(__file__)))
BIN = 5          # seconds per bin for latency / throughput curves
SETTLE = 15      # seconds after scale-out before the "after" window starts


def read_csv(name):
    path = os.path.join(BASE, name)
    if not os.path.exists(path):
        raise SystemExit(f"Missing {path}")
    with open(path) as f:
        return list(csv.DictReader(f))


cpu_rows = read_csv("cpu_log.csv")
event_rows = read_csv("events.csv")
req_rows = read_csv("integrated_demo_results.csv")

# first occurrence of each event; "CLIENT_LOW_START rate=25" -> "CLIENT_LOW_START"
events = {}
for e in event_rows:
    events.setdefault(e["event"].split()[0], float(e["timestamp"]))

for needed in ("AUTOSCALER_START", "CLIENT_HIGH_START"):
    if needed not in events:
        raise SystemExit(f"events.csv has no {needed}; run the demo first")

T0 = events["AUTOSCALER_START"]
rel = lambda t: t - T0

# ---------- load data ----------
cpu = {}
for r in cpu_rows:
    cpu.setdefault(r["vm"], ([], []))
    cpu[r["vm"]][0].append(rel(float(r["timestamp"])))
    cpu[r["vm"]][1].append(float(r["cpu_percent"]))

reqs = []
for r in req_rows:
    reqs.append({
        "start": rel(float(r["start_time"])),
        "end": rel(float(r["end_time"])),
        "lat": float(r["latency_seconds"]),
        "ok": r["success"] == "True",
        "server": r["reported_server"] or r["server"],
    })
good = [r for r in reqs if r["ok"]]
if not good:
    raise SystemExit("No successful requests in the results CSV")

tmax = max(r["end"] for r in good)
edges = np.arange(0, tmax + BIN, BIN)
centers = edges[:-1] + BIN / 2

# ---------- binned curves ----------
mean_lat, p95_lat = [], []
for lo, hi in zip(edges[:-1], edges[1:]):
    lats = [r["lat"] for r in good if lo <= r["start"] < hi]
    mean_lat.append(statistics.mean(lats) if lats else np.nan)
    p95_lat.append(np.percentile(lats, 95) if lats else np.nan)

servers = sorted({r["server"] for r in good})
tput = {}
for s in servers:
    ends = [r["end"] for r in good if r["server"] == s]
    counts, _ = np.histogram(ends, bins=edges)
    tput[s] = counts / BIN
total_tput = sum(tput.values())

# ---------- markers ----------
markers = [
    ("CLIENT_HIGH_START", "high load starts", "gray", ":"),
    ("VM2_CREATE_CALLED", "server2 create()", "orange", "--"),
    ("SERVER2_READY_PUBLISHED", "server2 ready, client notified", "red", "-"),
]


def add_markers(ax, label=False):
    for key, text, color, style in markers:
        if key in events:
            ax.axvline(rel(events[key]), color=color, linestyle=style,
                       linewidth=1.5, label=text if label else None)


# ---------- combined figure ----------
fig, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True)

ax = axes[0]
for vm, (t, c) in sorted(cpu.items()):
    ax.plot(t, c, marker=".", label=f"{vm} CPU")
ax.axhline(60, color="black", linestyle="-.", linewidth=0.8, label="threshold (60%)")
add_markers(ax, label=True)
ax.set_ylabel("CPU utilization (%)")
ax.set_ylim(0, 105)
ax.set_title("Autoscaling demo: CPU, latency and throughput")
ax.legend(loc="lower left", fontsize=8, ncol=2)

ax = axes[1]
ax.plot(centers, mean_lat, marker="o", label="mean latency")
ax.plot(centers, p95_lat, marker="s", label="P95 latency")
add_markers(ax)
ax.set_ylabel("Latency (s)")
ax.legend(loc="upper left", fontsize=8)

ax = axes[2]
for s in servers:
    ax.plot(centers, tput[s], marker=".", label=f"{s} completed/s")
ax.plot(centers, total_tput, color="black", linewidth=2, label="total")
add_markers(ax)
ax.set_ylabel("Throughput (req/s)")
ax.set_xlabel(f"Time since autoscaler start (s)   [{BIN}s bins]")
ax.legend(loc="upper left", fontsize=8)

fig.tight_layout()
fig.savefig(os.path.join(BASE, "autoscaling_summary.png"), dpi=150)
print("Saved autoscaling_summary.png")

# ---------- before/after table ----------
low_start = rel(events.get("CLIENT_LOW_START", events["AUTOSCALER_START"]))
high_start = rel(events["CLIENT_HIGH_START"])
send_done = rel(events.get("CLIENT_SENDING_DONE", tmax))
windows = [("LOW load", low_start, high_start)]
if "SERVER2_READY_PUBLISHED" in events:
    ready = rel(events["SERVER2_READY_PUBLISHED"])
    windows.append(("HIGH, before scale-out", high_start, ready))
    windows.append((f"HIGH, after scale-out (+{SETTLE}s)", ready + SETTLE, send_done))
else:
    windows.append(("HIGH (no scale-out happened)", high_start, send_done))

rows = []
for name, lo, hi in windows:
    if hi <= lo:
        continue
    span = hi - lo
    sel = [r for r in good if lo <= r["start"] < hi]
    failed = sum(1 for r in reqs if (not r["ok"]) and lo <= r["start"] < hi)
    done = sum(1 for r in good if lo <= r["end"] < hi)
    lats = [r["lat"] for r in sel]

    def cpu_mean(vm):
        if vm not in cpu:
            return float("nan")
        v = [c for t, c in zip(*cpu[vm]) if lo <= t < hi]
        return statistics.mean(v) if v else float("nan")

    rows.append({
        "window": name,
        "seconds": round(span, 1),
        "server1_cpu_%": round(cpu_mean("server1"), 1),
        "server2_cpu_%": round(cpu_mean("server2"), 1),
        "mean_latency_s": round(statistics.mean(lats), 3) if lats else "",
        "p95_latency_s": round(float(np.percentile(lats, 95)), 3) if lats else "",
        "throughput_req_s": round(done / span, 2),
        "failed_requests": failed,
    })

if rows:
    keys = list(rows[0].keys())
    print()
    print(" | ".join(keys))
    for r in rows:
        print(" | ".join(str(r[k]) for k in keys))
    with open(os.path.join(BASE, "summary_stats.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print("\nSaved summary_stats.csv")
