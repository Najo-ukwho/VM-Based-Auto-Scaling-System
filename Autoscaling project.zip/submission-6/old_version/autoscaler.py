import csv
import json
import os
import time
import urllib.request

import libvirt

libvirt.registerErrorHandler(lambda ctx, err: None, None)

libvirt.registerErrorHandler(lambda ctx, err: None, None)

VM1_NAME = "server1"
VM2_NAME = "server2"

THRESHOLD = 60.0
CHECK_INTERVAL = 2
REQUIRED_HIGH_SAMPLES = 2
BOOT_TIMEOUT = 180  # seconds to wait for server2's app

BASE = os.path.dirname(os.path.abspath(__file__))
SERVERS_FILE = os.path.join(BASE, "available_servers.json")
CPU_LOG = os.path.join(BASE, "cpu_log.csv")
EVENT_LOG = os.path.join(BASE, "events.csv")
SERVER2_XML = os.path.join(os.path.dirname(os.path.abspath(__file__)), "server2.xml")

SERVER1_URL = "http://192.168.122.202:8000"
SERVER2_URL = "http://192.168.122.21:8000"


def publish_servers(servers):
    tmp = SERVERS_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(servers, f)
    os.replace(tmp, SERVERS_FILE)
    print("Published server list:", servers, flush=True)


def server_ready(url):
    try:
        with urllib.request.urlopen(url + "/?n=100", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def init_logs():
    with open(CPU_LOG, "w", newline="") as f:
        csv.writer(f).writerow(["timestamp", "vm", "cpu_percent"])
    with open(EVENT_LOG, "w", newline="") as f:
        csv.writer(f).writerow(["timestamp", "event"])


def log_cpu(vm, cpu):
    with open(CPU_LOG, "a", newline="") as f:
        csv.writer(f).writerow([f"{time.time():.3f}", vm, f"{cpu:.2f}"])


def log_event(event):
    print(f"EVENT: {event}", flush=True)
    with open(EVENT_LOG, "a", newline="") as f:
        csv.writer(f).writerow([f"{time.time():.3f}", event])


prev = {}


def sample(conn, name):
    try:
        dom = conn.lookupByName(name)
    except libvirt.libvirtError:
        prev.pop(name, None)  # domain not defined (yet)
        return None
    info = dom.info()
    now = time.monotonic()
    if info[0] != libvirt.VIR_DOMAIN_RUNNING:
        prev.pop(name, None)
        return None
    cpu_ns = info[4]
    util = None
    if name in prev:
        p_cpu, p_t = prev[name]
        util = 100.0 * ((cpu_ns - p_cpu) / 1e9) / (now - p_t)
        util = max(0.0, min(100.0, util))
    prev[name] = (cpu_ns, now)
    return util


def get_or_define_vm2(conn):
    """Return the server2 domain; define it from server2.xml if it is missing."""
    try:
        return conn.lookupByName(VM2_NAME)
    except libvirt.libvirtError:
        with open(SERVER2_XML) as f:
            xml = f.read()
        dom = conn.defineXML(xml)
        if dom is None:
            raise RuntimeError("defineXML failed for server2")
        log_event("VM2_DEFINED_FROM_XML")
        return dom


def main():
    conn = libvirt.open("qemu:///system")
    if conn is None:
        raise SystemExit("Cannot connect to libvirt")

    if conn.lookupByName(VM1_NAME).info()[0] != libvirt.VIR_DOMAIN_RUNNING:
        raise SystemExit("server1 must be running before autoscaling")

    init_logs()
    publish_servers([SERVER1_URL])
    log_event("AUTOSCALER_START")

    state = "MONITORING"
    high_samples = 0
    scale_started = 0.0

    sample(conn, VM1_NAME)
    sample(conn, VM2_NAME)

    try:
        while True:
            time.sleep(CHECK_INTERVAL)

            cpu1 = sample(conn, VM1_NAME)
            cpu2 = sample(conn, VM2_NAME)
            if cpu1 is not None:
                log_cpu(VM1_NAME, cpu1)
                print(f"server1 CPU: {cpu1:.1f}%", flush=True)
            if cpu2 is not None:
                log_cpu(VM2_NAME, cpu2)
                print(f"server2 CPU: {cpu2:.1f}%", flush=True)

            if state == "MONITORING":
                if cpu1 is not None and cpu1 >= THRESHOLD:
                    high_samples += 1
                else:
                    high_samples = 0

                if high_samples >= REQUIRED_HIGH_SAMPLES:
                    log_event("OVERLOAD_DETECTED")
                    vm2 = get_or_define_vm2(conn)
                    if vm2.info()[0] != libvirt.VIR_DOMAIN_RUNNING:
                        vm2.create()
                    log_event("VM2_CREATE_CALLED")
                    scale_started = time.monotonic()
                    state = "SCALING"

            elif state == "SCALING":
                if server_ready(SERVER2_URL):
                    publish_servers([SERVER1_URL, SERVER2_URL])
                    log_event("SERVER2_READY_PUBLISHED")
                    state = "SCALED"
                elif time.monotonic() - scale_started > BOOT_TIMEOUT:
                    log_event("SCALE_TIMEOUT")
                    high_samples = 0
                    state = "MONITORING"

    except KeyboardInterrupt:
        print("\nAutoscaler stopped.", flush=True)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
