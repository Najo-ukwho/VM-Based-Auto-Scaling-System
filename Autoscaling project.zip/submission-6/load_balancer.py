import concurrent.futures
import requests
import time
import statistics
import csv
import json
import threading
import os

SERVERS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "available_servers.json")

TOTAL_REQUESTS = 100
CONCURRENCY = 10
REQUEST_LIMIT = 80000

counter = 0
lock = threading.Lock()

def get_servers():
    try:
        with open(SERVERS_FILE) as f:
            servers = json.load(f)
        return servers if servers else []
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def choose_server():
    global counter

    with lock:
        servers = get_servers()
        if not servers:
            raise RuntimeError("No available servers published yet")
        server = servers[counter % len(servers)]
        counter += 1
        return server

def send_request(_):
    start = time.perf_counter()
    server = None

    try:
        server = choose_server()
        response = requests.get(
            f"{server}/?n={REQUEST_LIMIT}",
            timeout=60
        )
        response.raise_for_status()
        latency = time.perf_counter() - start
        return server, latency, True
    except Exception as e:
        print("Request failed:", e)
        return server, None, False

start_all = time.perf_counter()

with concurrent.futures.ThreadPoolExecutor(
    max_workers=CONCURRENCY
) as pool:
    results = list(pool.map(send_request, range(TOTAL_REQUESTS)))

total_time = time.perf_counter() - start_all
successful = [r for r in results if r[2]]
latencies = [r[1] for r in successful]

print("\n--- Autoscaling Client Results ---")
print(f"Successful requests: {len(successful)}/{TOTAL_REQUESTS}")
print(f"Total elapsed time:  {total_time:.2f} seconds")

if total_time > 0:
    print(f"Throughput:          {len(successful)/total_time:.2f} requests/sec")

if latencies:
    ordered = sorted(latencies)
    print(f"Mean latency:        {statistics.mean(latencies):.3f} seconds")
    print(f"Median latency:      {statistics.median(latencies):.3f} seconds")
    print(f"95th percentile:     {ordered[int(0.95*(len(ordered)-1))]:.3f} seconds")

print("\nRequests handled by each server:")
for server in sorted({r[0] for r in successful}):
    print(f"{server}: {sum(1 for r in successful if r[0] == server)}")

with open("autoscaling_results.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["server", "latency_seconds"])
    writer.writerows(
        [[server, latency] for server, latency, ok in results if ok]
    )

print("Saved results to autoscaling_results.csv")
