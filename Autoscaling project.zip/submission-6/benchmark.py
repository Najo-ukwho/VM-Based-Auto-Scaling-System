import concurrent.futures
import requests
import time
import statistics
import csv

URL = "http://192.168.122.202:8000/?n=80000"
TOTAL_REQUESTS = 100
CONCURRENCY = 10

def send_request(_):
    start = time.perf_counter()
    try:
        response = requests.get(URL, timeout=60)
        response.raise_for_status()
        elapsed = time.perf_counter() - start
        return elapsed, True
    except Exception as e:
        print("Request failed:", e)
        return None, False

start_all = time.perf_counter()

with concurrent.futures.ThreadPoolExecutor(
    max_workers=CONCURRENCY
) as pool:
    results = list(pool.map(send_request, range(TOTAL_REQUESTS)))

total_time = time.perf_counter() - start_all
latencies = [elapsed for elapsed, ok in results if ok]
successes = len(latencies)

print("\n--- Single-VM Baseline ---")
print(f"Successful requests: {successes}/{TOTAL_REQUESTS}")
print(f"Total elapsed time:  {total_time:.2f} seconds")
print(f"Throughput:          {successes / total_time:.2f} requests/sec")

if latencies:
    print(f"Mean latency:        {statistics.mean(latencies):.3f} seconds")
    print(f"Median latency:      {statistics.median(latencies):.3f} seconds")
    print(f"95th percentile:     {sorted(latencies)[int(0.95 * (len(latencies)-1))]:.3f} seconds")

with open("baseline.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["latency_seconds"])
    writer.writerows([[x] for x in latencies])

print("Saved successful request latencies to baseline.csv")
